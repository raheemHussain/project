#include "stdafx.h"
#include "HRRiskAssessment.h"
#include <fstream>
#include <iostream>
#include <string>
using namespace std;


int LoadMeasurements(char* inputFile, HRData data[], int maxSize)
{
	ifstream LoadMeasurements(inputFile);

	string OutputData;
	int ListSize = 0;


	if (inputFile)
	{
		LoadMeasurements >> noskipws; //This will make sure that there is no white spaces

		while (!LoadMeasurements.eof() && ListSize < MAX_DATA) 
		{
			char CurrentChar;
			LoadMeasurements >> CurrentChar;
			if (CurrentChar == '\n' || CurrentChar == '\r') //This will take out all the new line and the returns
			{
				//
			}
			else
			{
				OutputData += CurrentChar;
				if (CurrentChar == ',')
				{
					if (OutputData == "Date," || OutputData == "HR,")
					{
						//
					}
					else if ((OutputData.size() - 1) == DATE_SIZE)
					{
						for (int i = 0; i < DATE_SIZE; i++)
						{
							data->date[i] = OutputData[i];
						}
					}
					else
					{
						data->hr = stoi(OutputData);
						data++;
						ListSize++;
					}
					OutputData = "";
				}
			}
		}

	}
	else if (!inputFile)
	{
		return InvalidParameters; //If the file does not exist then it will bring an invalid parameter
	}

	LoadMeasurements.close(); //This will close the loadmeasurements when its done using it 
	return ListSize; 

}

int CallDLL(WCHAR* dllName, HRData data[], int count)
{
	typedef int(*MYPROC)(HRData data[], int count);
	/* don�t worry about _cdecl. It is a calling convention � this program behaves
	the same if _cdecl is omitted */

	HINSTANCE hinstLib;
	MYPROC ProcAdd;
	BOOL fFreeResult, fRunTimeLinkSuccess = FALSE;

	int risk = -1;

	// Get a handle to the DLL module.

	hinstLib = LoadLibrary(dllName);

	// If the handle is valid, try to get the function address.

	if (hinstLib != NULL)
	{
		ProcAdd = (MYPROC)GetProcAddress(hinstLib, "AssessRisk");

		// If the function address is valid, call the function.

		if (NULL != ProcAdd)
		{
			fRunTimeLinkSuccess = TRUE;
			risk = (ProcAdd)(data, count);
			return risk;
		}

		// Free the DLL module.
		fFreeResult = FreeLibrary(hinstLib);
	}

	// Report any failures
	if (!fRunTimeLinkSuccess)
		return DllNotFound;

	return Failure;
}

void Sort(HRData data[], int count) //Bubble Sort //
{
	bool Switch = true; //This will determine whether or not switch
	int ListSize = count; //An integer of what value is in count

	while (Switch) //If the number next to it is greater then the one next to it switch 
	{
		Switch = false;

		for (int i = 0; i < ListSize - 1; i++)
		{
			if (data[i].hr > data[i + 1].hr)
			{
				HRData temp = data[i];
				data[i] = data[i + 1];
				data[i + 1] = temp;
				Switch = true;
			}
		}
	}
}

void Quicksort(HRData data[], int left, int right) // Quicksort //
{
	{
		int i = left; //Have a left interger of what position it is currently in 
		int j = right; // Have a left interger of what position it is currently in 
		HRData tempData; //Hold the temporary data 
		int pivot = data[(left + right) / 2].hr; 

		while (i <= j)
		{
			while (data[i].hr < pivot) 
			{
				i++;
			}

			while (data[j].hr > pivot)
			{
				j--;
			}

			if (i <= j)
			{
				tempData = data[i];
				data[i] = data[j];
				data[j] = tempData;
				i++;
				j--;
			}
		}
		if (left < j)
			Quicksort(data, left, j); //This will put everything in the correct order in the left interger

		if (i < right)
			Quicksort(data, i, right); //This will put everything in the correct order in the right interger
	}
}
