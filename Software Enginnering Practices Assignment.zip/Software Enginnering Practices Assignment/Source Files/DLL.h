#include "HRRiskAssessment.h"

#ifdef __cplusplus    // If used by C++ code, 
extern "C" {          // we need to export the C interface � with no name mangling
#endif

	_declspec(dllexport) int AssessRisk(HRData data[], int count);

#ifdef __cplusplus    // If used by C++ code, 
}  // end extern "C"
#endif




