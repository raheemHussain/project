#include "stdafx.h"
#include "HRRiskAssessment.h" // You can also place this inside "stdafx.h"
#include <iostream>

using namespace std;

int _tmain(int argc, _TCHAR* argv[]) {

	HRData data[MAX_DATA];

	// Change "Debug" to "Release" for release mode
#if _DEBUG
	char *inputFile = "..\\Debug\\HR.csv"; //If mode is in debug it will go into this 
#else
	char *inputFile = "..\\Release\\HR.csv"; //If mode is in release it will go into this 
#endif

	int count = LoadMeasurements(inputFile, data, MAX_DATA);
	cout << "Measurements loaded:" << count << endl;

	/////////////	Bubblesort Display  /////////////////

	int startTime = GetTickCount();

	//Sort(data, count); //Bubble Sort Function//
	Quicksort(data, 0,count-1);

	int endTime = GetTickCount();

	int ms = endTime - startTime;
	
	//Output the data and sort the data in number order
	for (int i = 0; i < count; i++)
	{
		for (int j = 0; j < DATE_SIZE; j++)
		{
			cout << data[i].date[j];
		}
	}



	if (count > 0) {
		int status = CallDLL(L"DLL_Assess_1.DLL", data, count);
		switch (status) {
		case RiskDetected: cout << "Risk detected!" << endl;
			break;
		case NoRisk: cout << "No Risk" << endl;
			break;
		case UnknownError: cout << "Unknown Error or Error inside DLL" << endl;
			break;
		case DllInvalidFormat: cout << "Invalid function parameters" << endl;
			break;
		case DllNotFound: cout << "DLL Not Found" << endl;
			break;
		}
	}

	system("pause");
	return 0;
}
