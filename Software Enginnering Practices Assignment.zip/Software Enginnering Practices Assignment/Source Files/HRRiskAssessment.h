#include "stdafx.h"
#include <Windows.h>
const int RiskDetected = 1;
const int NoRisk = 0;

const int Success = 0;
const int Failure = -1;
const int DllNotFound = -2;		// can't find dll to import
const int DllInvalidFormat = -3;	// Unable to find import function in the dll
const int UnknownError = -4;
const int InvalidParameters = -5;

const int MAX_DATA = 12000;  // the maximum size of the array for loading data 
const int DATE_SIZE = 19;  // the maximum size of a date as a null-terminated string

class HRData {
public:
	char date[DATE_SIZE];
	int hr;
};

int LoadMeasurements(char* inputFile, HRData data[], int max_size); 
int CallDLL(WCHAR* dllName, HRData data[], int count);
void Sort(HRData data[], int count); //This will reach the method with its specific parameters 
void Quicksort(HRData data[], int left, int right); //This will reach the method with its specific parameters 