/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment;

/**
 *
 * @author Raheem
 */
public class Timing extends Thread{
        private long startTime = 0;
    private long time = 0;
    private boolean running;
    
    public Timing()
    {
        startTime = 0L;
        time = 0L;
        running = false;
    }
    
    public long getTime()
    {
        System.out.println(time);
        return time;
    }
    
    @Override
    public void start()
    {
        System.out.println("Start");
        time = 0L;
        startTime = System.currentTimeMillis();
        running = true;

        super.start();
    }
    
    @Override
    public void run()
    {
        while (running)
        {
            //System.out.println("Running");
            time = System.currentTimeMillis() - startTime;              //sleep for interval between checks                                                         
            try
            {
                sleep(10);
                if (time > 200000000)
                {
                    running = !running;
                }
            } catch (InterruptedException ex)
            {
                ex.printStackTrace();
            }
        }
    }
}
    

