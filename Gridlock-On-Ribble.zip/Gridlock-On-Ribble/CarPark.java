/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment;

/**
 *
 * @author Raheem
 */
public class CarPark extends Thread{
    Road buf;
    int id;
    
    public CarPark(Road b, int NumConsume){
        buf=b;
        id=NumConsume;
    }
    
    public boolean Consume(){
        Vehicle nextItem = buf.extract();                                       //Makes the vehicle extract onto the buffer 
        System.out.println("Car Park " + id + "Consuming Car: " + nextItem.id);
        if (nextItem==null){
            return false;
        }else{
            return true;
        }   
    }
    
    public void run(){
        while(Consume()){
            try{
                sleep ((int)(Math.random() * 5));                               //This is the time that it sleeps for  
            }catch(InterruptedException ex){
                
            }
        }
        System.out.println("Finished Consuming");                               //Once it is done consuming the message should be up
    }        
}


    
    
