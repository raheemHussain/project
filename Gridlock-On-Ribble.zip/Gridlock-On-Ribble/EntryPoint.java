/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment;

/**
 *
 * @author Raheem
 */
public class EntryPoint extends Thread  {
    Road buf;
    int id;
    int number;
    
    public EntryPoint(int id, Road b,int NumOfItems){
        this.id = id;
        buf = b;
        number = NumOfItems;                                             
    }
    
    public void Produce(int i){
        System.out.println("Entry Point " + id + "Producing Car: "+ i);
        int answer = (int)(Math.random() * ((4 - 1) + 1)) + 1;
        Vehicle newVehicle = new Vehicle(i,answer);
        buf.insert(newVehicle);                                         //Producing the vehicle 
    }
    
    public void run(){
        for (int i = 0; i<number; i++){
            
            Produce(i);                                                 //Loops around with the number of vehicles and their id 
        } 
        System.out.println("Finished Producing");
    }    
}
    


