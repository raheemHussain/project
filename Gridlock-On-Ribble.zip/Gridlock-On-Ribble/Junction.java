/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment;

/**
 *
 * @author Raheem
 */
public class Junction extends Thread {
    Road North;
    Road South;
    Road East;
    Road West;
    
    Road EntryBuf;
    int id;
    int destination;
    long CurrentTime;
    long NextChange;
    
    public Junction(int id, Road EntryB, Road BNorth, Road BSouth, Road BEast, Road BWest){
        this.id=id;
        EntryBuf = EntryB;
        North = BNorth;
        South = BSouth;
        East = BEast;
        West = BWest; 
        CurrentTime = Assignment.Clock.getTime();
        NextChange = CurrentTime;
        
    }
    
    public void run(){
        while(true)
        {
            Vehicle newVehicle = EntryBuf.extract();
            destination = newVehicle.destination();
            System.out.println("Junction " + id + "Passing Cars:  " + newVehicle.id);
            
            if(id == 1){
                if(destination == 1){
                    West.insert(newVehicle);
                }
                
                if(destination == 2){
                    North.insert(newVehicle);
                }
                
                if(destination == 3){
                    North.insert(newVehicle);
                }
                
                if(destination == 4){
                    North.insert(newVehicle);
                }
            }
            
            if(id ==2){
                if(destination == 1){
                    South.insert(newVehicle);
                }
                
                if(destination == 2){
                    North.insert(newVehicle);
                }
                
                if(destination == 3){
                    North.insert(newVehicle);
                }
                
                if(destination == 4){
                    North.insert(newVehicle);
                }   
            }
            
            if(id == 3){
                if(destination == 1){
                    East.insert(newVehicle);
                }
                
                if(destination == 2){
                    South.insert(newVehicle);
                }
                
                if(destination == 3){
                    West.insert(newVehicle);
                }
                
                if(destination == 4){
                    West.insert(newVehicle);
                }
            }
            
            if(id == 4){
                
                if (destination == 3){
                    North.insert(newVehicle);
                }
                
                if(destination == 4){
                    South.insert(newVehicle);
                }
            }
            
        }
    } 
}
