/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment;

/**
 *
 * @author Raheem
 */
public class Assignment {

    /**
     */
    public static Timing Clock;
    
    public static void main(String[] args) {
        
        Clock = new Timing();
        
        Road Empty = new Road(1);
        
        Road b = new Road(60);                                               
        Road b1= new Road(15); 
        Road b2= new Road(7);
        Road b3 = new Road(10);
        Road b4 = new Road(50);
        Road b5 = new Road(7);
        Road b6 = new Road(10);
        Road b7 = new Road(15);
        Road b8 = new Road(15);
        Road b9 = new Road(30);
        
        CarPark con1 = new CarPark(b1,1);
        CarPark con2 = new CarPark(b5,2);
        CarPark con3 = new CarPark(b7,3);
        CarPark con4 = new CarPark(b8,4);
        
        EntryPoint pro = new EntryPoint(1,b,550);
        //Producer pro1 = new Producer(2,b9,300);
        //Producer pro2 = new Producer(3,b4,550);
       
        Junction procon1 = new Junction(1, b, b2, Empty, Empty,b1);         //The pararmeter that it will need is the id and the road it is on and is going ont
        Junction procon2 = new Junction(2,b2,b3,Empty,b9,Empty);
        Junction procon3 = new Junction(3,b3,b4,b5,Empty,b6);
        Junction procon4 = new Junction(4,b6,b7,b8,Empty,Empty);
        
        con1.start();                                                                        //Starting the threads 
        pro.start();
        procon1.start();
        procon2.start();
        procon3.start();
        procon4.start();
        con2.start();
        con3.start();
        con4.start();
        Clock.start();
        //pro1.start();
        //pro2.start();
        try{
            pro.join();                                                                     //Making the thread join together
            con1.join();
            procon1.join();
            procon2.join();
            procon3.join();
            procon4.join();
            con2.join();
            con3.join();
            con4.join();
            Clock.join();
            //pro1.join();
            //pro2.join();
        }catch (InterruptedException ex){      
        }
    }
    }

