/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment;

import java.util.concurrent.Semaphore;


/**
 *
 * @author Raheem
 */
class Road {
    private Vehicle[]body;  //Size of Road
    int BodySize;
    
    private int NextIn = 0;
    private int NextOut = 0;
    
    public Semaphore mutex = new Semaphore(1);
    public Semaphore numAvail = new Semaphore(0);
    public Semaphore numFree = new Semaphore(BodySize);
    
    public Road(int size){
        body = new Vehicle[size];
        BodySize = size;
    }
    
    public void insert(Vehicle item){
        try{
            mutex.acquire();
            numFree.tryAcquire();
        }catch (InterruptedException ex){                                       //Insert the vehicle onto the buffer 
            System.out.println("Interrupted Caught Mate");
        }
        
        body[NextIn]=item;                                                      //It gets the vehicle one by one 
        try{
            Thread.sleep((int)(Math.random() * 10));
        }catch (InterruptedException ex){
        }
        
        NextIn++;                                                               //Add them into the buffer one at a time 
        if(NextIn == body.length){
            NextIn = 0;
        }
        
        numAvail.release();
        mutex.release();
        
    }
    
    public Vehicle extract(){                                                   //This will extract it from the buffer onto the road 
        try{
            numAvail.acquire();
            mutex.acquire();
        }catch(InterruptedException e){
            System.out.println("Interrupted Exception LAD");
        }
        
        Vehicle res = new Vehicle(-1, 1);
        res = body[NextOut];
        try{
            Thread.sleep((int)(Math.random() * 10));
        }catch (InterruptedException ex){
        }
        
        if (res==null){
            System.out.println("Vehicle being extracted is NULL");
        }
        
        NextOut++;
        
        if(NextOut == body.length){
            NextOut = 0;
        }
        
        numFree.release();
        mutex.release();
        
        return res;
    }            
}
